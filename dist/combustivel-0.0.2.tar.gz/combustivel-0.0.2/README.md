# Cálculo de Viagem

Descição
O pacote combustivel é usado para calcular a quantidade de litros gastos em uma viagem

## Instalação
Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/) para instalar combustivel

```bash
pip install combustivel
```

## Utilização

```python
from combustivel import calc_combustivel
calc_combustivel.calcula_litros()
```

## Autor
Samuel Fabiano

## License
[MIT](https://choosealicense.com/licenses/mit/)
