def calcula_litros(tempo,velocidade_media):
    distancia = tempo * velocidade_media
    litros = distancia / 12
    return litros